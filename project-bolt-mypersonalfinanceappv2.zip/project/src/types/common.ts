export type Theme = 'light' | 'dark' | 'system';
export type Currency = string;